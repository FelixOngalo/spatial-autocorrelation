# Simulate 400 point locations (think: neighbourhood-level incident
# rates, soil measurements, or store sales) on a 100 x 100 plane, with
# TWO engineered hotspots. Knowing where the real hotspots are lets
# the project grade the local spatial statistic on precision/recall.
# A second, SHUFFLED copy of the same values (same numbers, locations
# scrambled) is the no-spatial-structure control.
library(dplyr)
library(readr)

set.seed(42)
n <- 400
centers <- tibble(cx = c(25, 75), cy = c(70, 30))

df <- tibble(id = seq_len(n), x = runif(n, 0, 100), y = runif(n, 0, 100)) |>
  mutate(
    d1 = sqrt((x - centers$cx[1])^2 + (y - centers$cy[1])^2),
    d2 = sqrt((x - centers$cx[2])^2 + (y - centers$cy[2])^2),
    value = 10 + 15 * exp(-d1^2 / (2 * 10^2)) + 15 * exp(-d2^2 / (2 * 10^2)) + rnorm(n, 0, 2),
    true_hotspot = d1 < 12 | d2 < 12
  ) |>
  select(id, x, y, value, true_hotspot)

df$value_shuffled <- sample(df$value)   # same distribution, no spatial pattern

write_csv(df, "data/raw/spatial_points.csv")
cat("Simulated", n, "points;", sum(df$true_hotspot), "lie inside a true hotspot\n")
