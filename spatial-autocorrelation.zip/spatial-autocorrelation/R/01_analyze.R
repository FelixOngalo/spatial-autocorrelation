library(dplyr)
library(readr)
source("R/spatial_functions.R")

df <- read_csv("data/raw/spatial_points.csv", show_col_types = FALSE)
coords <- as.matrix(df[, c("x", "y")])
W <- knn_weights(coords, k = 8)

cat("=== 1. Global Moran's I: clustered vs. shuffled values ===\n")
clustered <- moran_perm_test(df$value, W)
shuffled  <- moran_perm_test(df$value_shuffled, W)
cat("Clustered: I =", round(clustered$observed, 4), " p =", clustered$p_value, "\n")
cat("Shuffled:  I =", round(shuffled$observed, 4), " p =", shuffled$p_value, "\n")
cat("Expected I under no structure:", round(clustered$expected, 4), "\n")

cat("\n=== 2. Sensitivity of global I to the neighbourhood size k ===\n")
k_sens <- bind_rows(lapply(c(4, 8, 12, 20, 40), function(k) {
  Wk <- knn_weights(coords, k)
  tibble(k = k, morans_i = morans_i(df$value, Wk))
}))
print(k_sens)

cat("\n=== 3. Local Moran's I and hotspot detection ===\n")
local <- bind_cols(df, local_morans_i(df$value, W))
local <- local |> mutate(detected_hotspot = quadrant == "HH" & p_adj < 0.05)

confusion <- local |> count(true_hotspot, detected_hotspot)
print(confusion)
tp <- sum(local$true_hotspot & local$detected_hotspot)
precision <- tp / sum(local$detected_hotspot)
recall    <- tp / sum(local$true_hotspot)
cat("Precision:", round(precision, 3), " Recall:", round(recall, 3), "\n")

saveRDS(list(df = df, clustered = clustered, shuffled = shuffled, k_sens = k_sens,
             local = local, confusion = confusion, precision = precision, recall = recall),
        "data/clean/spatial_results.rds")
