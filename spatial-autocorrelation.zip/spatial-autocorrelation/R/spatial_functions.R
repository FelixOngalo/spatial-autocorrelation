# Spatial autocorrelation from scratch: neighbour weights, global
# Moran's I with a permutation test, and local Moran's I (LISA) with
# conditional permutation and false-discovery-rate control.
library(dplyr)
library(tibble)

#' Row-standardized k-nearest-neighbour weight matrix. W[i, j] = 1/k if
#' j is one of i's k nearest points, else 0. (Weights are not symmetric:
#' j can be among i's neighbours without the reverse holding.)
knn_weights <- function(coords, k = 8) {
  d <- as.matrix(dist(coords))
  diag(d) <- Inf                       # a point is never its own neighbour
  n <- nrow(d)
  W <- matrix(0, n, n)
  for (i in seq_len(n)) W[i, order(d[i, ])[seq_len(k)]] <- 1 / k
  W
}

#' Global Moran's I = (n / S0) * sum_ij w_ij z_i z_j / sum_i z_i^2,
#' where z = x - mean(x) and S0 = sum of all weights. Positive: similar
#' values cluster. Near E[I] = -1/(n-1): no spatial pattern. Negative:
#' checkerboard-like dispersion.
morans_i <- function(x, W) {
  z <- x - mean(x)
  (length(x) / sum(W)) * sum(z * (W %*% z)) / sum(z^2)
}

#' Permutation test for global Moran's I: shuffle the values across
#' locations nsim times to build the null distribution of I under "no
#' spatial structure", and compare. Returns observed I, the expected
#' value, the simulated null draws, and a one-sided pseudo p-value for
#' positive autocorrelation.
moran_perm_test <- function(x, W, nsim = 999, seed = 1) {
  set.seed(seed)
  obs <- morans_i(x, W)
  sims <- replicate(nsim, morans_i(sample(x), W))
  list(observed = obs, expected = -1 / (length(x) - 1), sims = sims,
       p_value = (1 + sum(sims >= obs)) / (nsim + 1))
}

#' Local Moran's I (LISA) for each location:
#'   I_i = (z_i / m2) * sum_j w_ij z_j,   m2 = sum(z^2) / n.
#' A large positive I_i means location i and its neighbours deviate
#' from the mean in the same direction. The quadrant says which way:
#'   HH hotspot (high among high), LL coldspot, HL / LH spatial outliers.
#' Significance uses CONDITIONAL permutation: hold z_i fixed and draw
#' random neighbour values from the other locations, nsim times.
#' Because ~n tests are run at once, p-values are also adjusted with
#' Benjamini-Hochberg (false discovery rate).
local_morans_i <- function(x, W, nsim = 499, seed = 1) {
  set.seed(seed)
  n <- length(x)
  k <- sum(W[1, ] > 0)
  z <- x - mean(x)
  m2 <- sum(z^2) / n
  lag <- as.vector(W %*% z)
  local_i <- z / m2 * lag

  p <- vapply(seq_len(n), function(i) {
    others <- z[-i]
    sim_lag <- replicate(nsim, mean(sample(others, k)))
    sim_i <- z[i] / m2 * sim_lag
    (1 + sum(abs(sim_i) >= abs(local_i[i]))) / (nsim + 1)
  }, numeric(1))

  tibble(
    z = z, lag = lag, local_i = local_i, p = p,
    p_adj = p.adjust(p, method = "BH"),
    quadrant = case_when(z > 0 & lag > 0 ~ "HH", z < 0 & lag < 0 ~ "LL",
                         z > 0 & lag < 0 ~ "HL", TRUE ~ "LH")
  )
}
