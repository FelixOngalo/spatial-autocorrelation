# Spatial Autocorrelation: Finding Hotspots with Moran's I

**Question:** *(fill in)* Is there spatial pattern in this variable, and where exactly are the clusters?

**Key findings:** *(fill in after running: global Moran's I clustered vs. shuffled, hotspot precision and recall)*

**Tools:** R, tidyverse, from-scratch Moran's I (global and local), permutation tests, Benjamini-Hochberg FDR, Quarto report

## Reproduce

1. `install.packages("tidyverse")`
2. Run `R/00_simulate_data.R`, then `R/01_analyze.R`
3. Render `reports/report.qmd`

## Data

400 simulated points on a 100 x 100 plane with two Gaussian hotspots (known locations), plus a shuffled copy of the values as a no-structure control.

## Method in brief

1. Row-standardized k-nearest-neighbour weights.
2. Global Moran's I with a permutation test; compare clustered vs. shuffled data; sensitivity to k.
3. Local Moran's I (LISA) with conditional permutation and FDR adjustment; classify HH / LL / HL / LH.
4. Grade detected hotspots against the known truth (precision, recall).

## Key concepts

| Concept | Meaning |
|---|---|
| Spatial autocorrelation | Nearby observations are more (or less) alike than distant ones |
| Weights matrix | Defines who counts as a neighbour; a modelling choice |
| Moran's I | Regression slope of the spatial lag on the centred value; null mean is -1/(n-1) |
| LISA | Local indicators: decompose global I by location |
| FDR | Controls the share of false discoveries when testing hundreds of locations |

## Project structure

```
R/00_simulate_data.R     points, hotspots, shuffled control
R/spatial_functions.R    knn_weights, morans_i, moran_perm_test, local_morans_i
R/01_analyze.R           run global and local analysis, grade hotspots
reports/report.qmd       derivations, plots, interpretation
```

## Limitations

- Planar coordinates, no edge-effect correction; use sf/spdep for real geographic data.
- Results depend on the chosen weights matrix.
- Simulated hotspots are cleaner than real ones.
- *(add your own)*
